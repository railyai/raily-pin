# Raily Keyring P1 — 3D print files (edition B, DA7280)

The **Raily Keyring P1** is a pocket-sized Bluetooth button that works with
[Raily AI](https://railyai.com). This archive contains the print and CAD files
for **edition B**, built for the SparkFun DA7280 haptic driver.

## Contents

| File | Description |
| --- | --- |
| `Raily-Keyring-P1-B.3mf` | Bambu Studio project for the A1 mini, 4 plates |
| `stl/` | STL files for every part (all other printers) |
| `stl/helpers/` | Support-enforcer volumes (tray and shelf) |
| `step/` | STEP files for most parts (see note below) |

## Plates and colours

| Plate | Part | Colour |
| --- | --- | --- |
| 1 | Tray 17.1 | Cotton White |
| 2 | Shelf 17.3c (DA7280 motor seat) | Cotton White |
| 3 | Cover 18.1e-B (face, frame, dowel sprue, TEST joint) | Pastel Periwinkle |
| 4 | Dowel pusher | Pastel Periwinkle |

Filament: **Polymaker Panchroma Matte PLA** — about 21 g Cotton White and
20 g Pastel Periwinkle. Total print time: about 3 h 45 min on the A1 mini.

## Print notes

- Supports are painted into the 3MF. Keep **auto supports off**.
- The shelf STL (`P1-B-shelf-17.3c-DA7280.stl`) includes a designed 5 mm brim.
  A no-brim version is also included. Snap the brim off after printing.
- Use the `stl/helpers/` support-enforcer volumes if your slicer supports them.
  Without enforcers, paint support under the tray loop and under the shelf
  plate and ledge.
- STEP files are provided for most parts. The tray and the cover frame are
  **not provided as STEP** (the exporter dropped faces); use their STL files.

## Hardware (closure A)

4 × M2×16 countersunk screws (ISO 7046-1) and 4 × M2 nuts (ISO 4032).

## Assembly and parts list

- Assembly guide (PDF): <https://atlas.railyai.com/downloads/raily-keyring-assembly-guide.pdf>
- Parts list and firmware guide: <https://atlas.railyai.com/build>
- MakerWorld: <https://makerworld.com/en/models/3380759>

## Licence

© 2026 Raily LLC. Licensed under
[CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/).
"Raily" and the Raily logo are trademarks of Raily LLC and are not covered by
this licence. See `LICENSE` for the full legal text.

# Raily Keyring P1 — 3D print files (edition B, DA7280)

The **Raily Keyring P1** is a pocket-sized Bluetooth button that works with
[Raily AI](https://railyai.com). This archive contains the print and CAD files
for **edition B**, built for the SparkFun DA7280 haptic driver.

## Contents

| File | Description |
| --- | --- |
| `Raily-Keyring-P1-B.3mf` | Bambu Studio project for the A1 mini, 4 plates |
| `stl/` | STL files for every part (all other printers) |
| `stl/helpers/` | Support-enforcer volumes (tray and shelf) and the frame's breakaway tie |
| `step/` | STEP files for most parts (see note below) |

## Plates and colours

| Plate | Part | Colour |
| --- | --- | --- |
| 1 | Tray 17.1 | Cotton White |
| 2 | Shelf 17.3c (DA7280 motor seat) | Cotton White |
| 3 | Cover 18.2-B (face, frame, dowel rack S / M / L) | Pastel Periwinkle |
| 4 | Dowel pusher (optional helper) | Pastel Periwinkle |

Filament: **Polymaker Panchroma Matte PLA** — about 21 g Cotton White and
20 g Pastel Periwinkle. Total print time: about 3 h 50 min on the A1 mini.

## Print notes

- Supports are painted into the 3MF. Keep **auto supports off**.
- The shelf STL (`P1-B-shelf-17.3c-DA7280.stl`) includes a designed 5 mm brim.
  A no-brim version is also included. Snap the brim off after printing.
- Use the `stl/helpers/` support-enforcer volumes if your slicer supports them.
  Without enforcers, paint support under the tray loop and under the shelf
  plate and ledge.
- Print `stl/helpers/P1-B-cover-18.2-B-frame-tie.stl` together with the frame,
  in the same position: it is a breakaway tie across the frame's USB notch.
  Snap it off after printing.
- The cover face prints best at 0.08 mm layers; the frame and the dowels at 0.16 mm.
- STEP files are provided for most parts. The tray and the cover frame are
  **not provided as STEP** (the exporter dropped faces); use their STL files.
- No part carries a part number. The STL and STEP files match the parts in
  the 3MF.

## Dowels

The dowel rack holds three sizes, ten of each: **S** 3.00 mm, **M** 3.05 mm and
**L** 3.10 mm. Start with S. If a dowel feels loose, swap it for the next size
up (M, then L). Press the dowels into the face first, then press the frame onto
them. Pushed into the frame first, they crack it.

## Hardware (closure A)

4 × M2×16 countersunk screws (ISO 7046-1) and 4 × M2 nuts (ISO 4032).

## Assembly and parts list

- Assembly guide (PDF): <https://atlas.railyai.com/downloads/raily-keyring-assembly-guide.pdf>
- Parts list and firmware guide: <https://atlas.railyai.com/build>
- MakerWorld: <https://makerworld.com/en/models/3380759>

## Licence

© 2026 Raily LLC. Licensed under
[CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/).
"Raily" and the Raily logo are trademarks of Raily LLC and are not covered by
this licence. See `LICENSE` for the full legal text.
